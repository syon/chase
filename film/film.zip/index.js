'use strict';

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const setup = require('./starter-kit/setup');
const AWS = require('aws-sdk');

const s3 = new AWS.S3();

exports.handler = (() => {
  var _ref = _asyncToGenerator(function* (event, context, callback) {
    // For keeping the browser launch
    context.callbackWaitsForEmptyEventLoop = false;
    // Use Uploaded Fontcache
    process.env.HOME = process.env.LAMBDA_TASK_ROOT;
    const browser = yield setup.getBrowser();
    exports.run(browser, event).then(function (result) {
      return callback(null, result);
    }).catch(function (err) {
      return callback(err);
    });
  });

  return function (_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
})();

exports.run = (() => {
  var _ref2 = _asyncToGenerator(function* (browser, event) {
    const { url, pocket_id: pocketId } = event;
    console.log('_________ exports.run _________');
    console.log(`URL: ${url}`);
    console.log(`URL: ${pocketId}`);
    const page = yield browser.newPage();
    page.setViewport({ width: 1024, height: 768 });
    yield page.goto(url);
    const buf = yield page.screenshot();
    yield page.close();
    yield s3Put(pocketId, buf);
    return 'done.';
  });

  return function (_x4, _x5) {
    return _ref2.apply(this, arguments);
  };
})();

function s3Put(pocketId, buf) {
  return new Promise((rv, rj) => {
    const obj = {
      Bucket: 'syon-chase',
      Key: `films/${pocketId}/pc.png`,
      Body: buf
    };
    console.log(`Saving object... ${obj.Key} (${buf.length} Bytes)`);
    // require('fs').writeFile('zzzzz.png', buf, (e)=>{});
    s3.putObject(obj, (err, data) => {
      if (err) {
        rj(err);
      }
      if (data) {
        console.log('Saved!');
        rv(data);
      }
    });
  });
}